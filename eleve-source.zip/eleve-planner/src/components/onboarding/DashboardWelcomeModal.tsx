import React, { useEffect, useRef } from "react";
import "./DashboardWelcomeModal.css";

interface DashboardWelcomeModalProps {
  isOpen: boolean;
  onStartPlanning: () => void;
  onDismiss: () => void;
}

/**
 * DashboardWelcomeModal
 * ---------------------------------------------------------------------------
 * Self-contained welcome modal for first-time dashboard visitors. Takes
 * `isOpen` + callbacks as props — no Context, no provider, no localStorage
 * logic inside the component itself (that lives in useDashboardWelcome).
 *
 * Usage (in DashboardPage.tsx):
 *
 *   const { isOpen, dismiss } = useDashboardWelcome();
 *   <DashboardWelcomeModal
 *     isOpen={isOpen}
 *     onDismiss={dismiss}
 *     onStartPlanning={() => { dismiss(); navigate("/planner"); }}
 *   />
 */
export const DashboardWelcomeModal: React.FC<DashboardWelcomeModalProps> = ({
  isOpen,
  onStartPlanning,
  onDismiss,
}) => {
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    dialogRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onDismiss();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onDismiss]);

  if (!isOpen) return null;

  return (
    <div className="eleve-dwm-overlay" role="presentation">
      <div
        className="eleve-dwm-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="eleve-dwm-title"
        aria-describedby="eleve-dwm-subtitle"
        tabIndex={-1}
        ref={dialogRef}
      >
        <div className="eleve-dwm-mark" aria-hidden="true">
          <svg width="26" height="26" viewBox="0 0 28 28" fill="none">
            <path
              d="M14 2L25 9V19L14 26L3 19V9L14 2Z"
              stroke="#B08D57"
              strokeWidth="1.2"
            />
            <circle cx="14" cy="14" r="3.5" fill="#B08D57" />
          </svg>
        </div>

        <h1 id="eleve-dwm-title" className="eleve-dwm-title">
          Welcome to Elevé
        </h1>
        <p id="eleve-dwm-subtitle" className="eleve-dwm-subtitle">
          Plan luxury resident experiences in minutes using templates or
          Elevé's AI Planning Engine.
        </p>

        <div className="eleve-dwm-actions">
          <button
            type="button"
            className="eleve-dwm-btn eleve-dwm-btn--ghost"
            onClick={onDismiss}
          >
            Dismiss
          </button>
          <button
            type="button"
            className="eleve-dwm-btn eleve-dwm-btn--primary"
            onClick={onStartPlanning}
            autoFocus
          >
            Start Planning
          </button>
        </div>
      </div>
    </div>
  );
};
