import { useState, useEffect, useCallback } from "react";

/**
 * useDashboardWelcome
 * ---------------------------------------------------------------------------
 * Minimal, self-contained onboarding state for the dashboard welcome modal.
 * No Context, no provider, no app-wide wiring — just a hook the Dashboard
 * page calls directly.
 *
 * Persists to localStorage so the modal only ever shows once per browser.
 * Bump STORAGE_KEY's version suffix if you ever want to re-show it to
 * everyone after a redesign.
 */

const STORAGE_KEY = "eleve_dashboard_welcome_seen_v1";

export function useDashboardWelcome() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    let alreadySeen = false;
    try {
      alreadySeen = window.localStorage.getItem(STORAGE_KEY) === "true";
    } catch {
      // localStorage unavailable (private browsing, blocked storage, etc.)
      // — fail open and show the modal rather than throwing.
      alreadySeen = false;
    }
    setIsOpen(!alreadySeen);
  }, []);

  const dismiss = useCallback(() => {
    setIsOpen(false);
    try {
      window.localStorage.setItem(STORAGE_KEY, "true");
    } catch {
      // Non-fatal — modal will simply show again next session.
    }
  }, []);

  return { isOpen, dismiss };
}
