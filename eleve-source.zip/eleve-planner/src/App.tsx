import { Routes, Route, Navigate } from 'react-router-dom'
import { Layout } from '@/components/layout/Layout'
import { LandingPage } from '@/pages/LandingPage'
import { PlannerPage } from '@/pages/PlannerPage'
import { SavedEventsPage } from '@/pages/SavedEventsPage'
import { DashboardWelcomeModal } from '@/components/onboarding/DashboardWelcomeModal'
import { useDashboardWelcome } from '@/hooks/useDashboardWelcome'
import { useNavigate } from 'react-router-dom'

function App() {
  const navigate = useNavigate()
  const { isOpen, dismiss } = useDashboardWelcome()

  return (
    <Layout>
      <DashboardWelcomeModal
        isOpen={isOpen}
        onDismiss={dismiss}
        onStartPlanning={() => {
          dismiss()
          navigate('/planner')
        }}
      />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/planner" element={<PlannerPage />} />
        <Route path="/saved" element={<SavedEventsPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  )
}

export default App
